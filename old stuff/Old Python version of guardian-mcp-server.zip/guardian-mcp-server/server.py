#!/usr/bin/env python3
"""
Guardian MCP Server
Provides access to The Guardian newspaper archive since 1999 through their Open Platform API
"""

import json
import sys
import os
import requests
import re
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from urllib.parse import urlencode

# Ensure unbuffered output
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 1)
sys.stderr = os.fdopen(sys.stderr.fileno(), 'w', 1)

# Server version
__version__ = "1.0.0"

# Guardian API configuration
GUARDIAN_API_BASE = "https://content.guardianapis.com"
API_KEY = os.environ.get("GUARDIAN_API_KEY")

if not API_KEY:
    print(json.dumps({
        "jsonrpc": "2.0",
        "error": {
            "code": -32603,
            "message": "Please set your Guardian API key in the GUARDIAN_API_KEY environment variable. Get your key from https://open-platform.theguardian.com/access/"
        }
    }), file=sys.stdout, flush=True)
    sys.exit(1)

def send_response(response: Dict[str, Any]):
    """Send a JSON-RPC response"""
    print(json.dumps(response), flush=True)

def validate_date(date_str: str) -> Optional[str]:
    """Validate and normalize date to YYYY-MM-DD format"""
    if not date_str:
        return None
    
    try:
        # Try parsing common date formats
        for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y"]:
            try:
                dt = datetime.strptime(date_str, fmt)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                continue
        
        # If no format matches, return None
        return None
    except Exception:
        return None

def calculate_date_from_days_back(days_back: int) -> str:
    """Calculate a date X days ago from today"""
    target_date = datetime.now() - timedelta(days=days_back)
    return target_date.strftime("%Y-%m-%d")

def make_guardian_request(endpoint: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Make a request to the Guardian API"""
    # Add API key to parameters
    params["api-key"] = API_KEY
    
    # Remove None values from parameters
    cleaned_params = {k: v for k, v in params.items() if v is not None}
    
    url = f"{GUARDIAN_API_BASE}{endpoint}"
    
    try:
        response = requests.get(url, params=cleaned_params, timeout=10)
        
        if response.status_code == 429:
            return {
                "error": "Rate limit exceeded. Guardian API allows 500 calls per day. Please try again later.",
                "status": "rate_limited"
            }
        elif response.status_code == 403:
            return {
                "error": "Invalid API key. Please check your GUARDIAN_API_KEY environment variable.",
                "status": "invalid_key"
            }
        elif response.status_code != 200:
            return {
                "error": f"Guardian API returned status code {response.status_code}: {response.text}",
                "status": "api_error"
            }
        
        return response.json()
    
    except requests.exceptions.Timeout:
        return {
            "error": "Request timed out. The Guardian API may be experiencing issues.",
            "status": "timeout"
        }
    except requests.exceptions.ConnectionError:
        return {
            "error": "Connection error. Please check your internet connection.",
            "status": "connection_error"
        }
    except Exception as e:
        return {
            "error": f"Unexpected error: {str(e)}",
            "status": "unknown_error"
        }

def format_article_response(articles: List[Dict], pagination_info: Dict = None) -> str:
    """Format article results for LLM consumption"""
    if not articles:
        return "No articles found matching your criteria."
    
    result = f"Found {len(articles)} article(s):\n\n"
    
    for i, article in enumerate(articles, 1):
        result += f"**{i}. {article.get('webTitle', 'Untitled')}**\n"
        
        if 'fields' in article:
            fields = article['fields']
            if 'byline' in fields:
                result += f"By: {fields['byline']}\n"
            if 'firstPublicationDate' in fields:
                pub_date = fields['firstPublicationDate'][:10]  # Extract date part
                result += f"Published: {pub_date}\n"
            if 'standfirst' in fields and fields['standfirst']:
                result += f"Summary: {fields['standfirst']}\n"
        
        result += f"Section: {article.get('sectionName', 'Unknown')}\n"
        result += f"URL: {article.get('webUrl', 'N/A')}\n"
        result += f"Guardian ID: {article.get('id', 'N/A')}\n"
        
        if 'fields' in article and 'body' in article['fields']:
            # Truncate body text for search results
            body = article['fields']['body']
            # Remove HTML tags
            body = re.sub(r'<[^>]+>', '', body)
            if len(body) > 500:
                body = body[:500] + "..."
            result += f"Content preview: {body}\n"
        
        result += "\n"
    
    if pagination_info and pagination_info.get('pages', 1) > 1:
        current_page = pagination_info.get('currentPage', 1)
        total_pages = pagination_info.get('pages', 1)
        result += f"\nPagination: Page {current_page} of {total_pages}\n"
        if current_page < total_pages:
            result += "Use the 'page' parameter to get more results.\n"
    
    return result

def handle_initialize(request_id: Any) -> Dict[str, Any]:
    """Handle initialization"""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {}
            },
            "serverInfo": {
                "name": "guardian",
                "version": __version__
            }
        }
    }

def handle_tools_list(request_id: Any) -> Dict[str, Any]:
    """List available tools"""
    tools = [
        {
            "name": "guardian_search",
            "description": "Search Guardian articles with flexible filtering options",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search terms (can be empty to browse all content)"
                    },
                    "section": {
                        "type": "string",
                        "description": "Filter by section ID (get available sections via guardian_get_sections)"
                    },
                    "tag": {
                        "type": "string",
                        "description": "Filter by tag (over 50,000 available tags)"
                    },
                    "from_date": {
                        "type": "string",
                        "description": "Start date (YYYY-MM-DD format)"
                    },
                    "to_date": {
                        "type": "string",
                        "description": "End date (YYYY-MM-DD format)"
                    },
                    "order_by": {
                        "type": "string",
                        "description": "Sort order: 'newest', 'oldest', 'relevance' (default: 'relevance')",
                        "enum": ["newest", "oldest", "relevance"]
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 200 (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number (default: 1)",
                        "minimum": 1
                    },
                    "show_fields": {
                        "type": "string",
                        "description": "Comma-separated fields to include (headline,standfirst,body,byline,thumbnail,publication)"
                    },
                    "production_office": {
                        "type": "string",
                        "description": "Filter by office: 'uk', 'us', 'au'",
                        "enum": ["uk", "us", "au"]
                    }
                }
            }
        },
        {
            "name": "guardian_get_article",
            "description": "Retrieve full content of a specific Guardian article",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "article_id": {
                        "type": "string",
                        "description": "The Guardian article ID (from search results)"
                    },
                    "show_fields": {
                        "type": "string",
                        "description": "Fields to include (default: headline,standfirst,body,byline,publication,firstPublicationDate)"
                    }
                },
                "required": ["article_id"]
            }
        },
        {
            "name": "guardian_longread",
            "description": "Search specifically for articles from The Long Read series",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search terms within Long Read articles"
                    },
                    "from_date": {
                        "type": "string",
                        "description": "Start date (YYYY-MM-DD format)"
                    },
                    "to_date": {
                        "type": "string",
                        "description": "End date (YYYY-MM-DD format)"
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 200 (default: 10)",
                        "minimum": 1,
                        "maximum": 200
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number (default: 1)",
                        "minimum": 1
                    }
                }
            }
        },
        {
            "name": "guardian_lookback",
            "description": "Find top stories from a specific date or date range",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "date": {
                        "type": "string",
                        "description": "Specific date (YYYY-MM-DD) or start of range"
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date for range (YYYY-MM-DD)"
                    },
                    "section": {
                        "type": "string",
                        "description": "Filter by section"
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Number of results (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    }
                },
                "required": ["date"]
            }
        },
        {
            "name": "guardian_browse_section",
            "description": "Browse recent articles from a specific Guardian section",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "section": {
                        "type": "string",
                        "description": "Section ID (use guardian_get_sections to find valid IDs)"
                    },
                    "days_back": {
                        "type": "integer",
                        "description": "How many days back to search (default: 7)",
                        "minimum": 1,
                        "maximum": 365
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Number of results, max 200 (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    }
                },
                "required": ["section"]
            }
        },
        {
            "name": "guardian_get_sections",
            "description": "Get all available Guardian sections",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        },
        {
            "name": "guardian_search_tags",
            "description": "Search through Guardian's 50,000+ tags to find relevant ones",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search term for tag names"
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 200 (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number (default: 1)",
                        "minimum": 1
                    }
                },
                "required": ["query"]
            }
        },
        {
            "name": "guardian_search_by_length",
            "description": "Search Guardian articles filtered by word count range",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search terms (optional)"
                    },
                    "min_words": {
                        "type": "integer",
                        "description": "Minimum word count (default: 0)",
                        "minimum": 0
                    },
                    "max_words": {
                        "type": "integer",
                        "description": "Maximum word count (default: unlimited)",
                        "minimum": 1
                    },
                    "section": {
                        "type": "string",
                        "description": "Filter by section ID"
                    },
                    "from_date": {
                        "type": "string",
                        "description": "Start date (YYYY-MM-DD format)"
                    },
                    "to_date": {
                        "type": "string",
                        "description": "End date (YYYY-MM-DD format)"
                    },
                    "order_by": {
                        "type": "string",
                        "description": "Sort order: 'newest', 'oldest', 'relevance' (default: 'newest')",
                        "enum": ["newest", "oldest", "relevance"]
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 200 (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    }
                }
            }
        },
        {
            "name": "guardian_search_by_author",
            "description": "Search Guardian articles by specific author/journalist",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "author": {
                        "type": "string",
                        "description": "Author name to search for"
                    },
                    "query": {
                        "type": "string",
                        "description": "Additional search terms within author's articles"
                    },
                    "section": {
                        "type": "string",
                        "description": "Filter by section ID"
                    },
                    "from_date": {
                        "type": "string",
                        "description": "Start date (YYYY-MM-DD format)"
                    },
                    "to_date": {
                        "type": "string",
                        "description": "End date (YYYY-MM-DD format)"
                    },
                    "order_by": {
                        "type": "string",
                        "description": "Sort order: 'newest', 'oldest', 'relevance' (default: 'newest')",
                        "enum": ["newest", "oldest", "relevance"]
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 200 (default: 20)",
                        "minimum": 1,
                        "maximum": 200
                    },
                    "page": {
                        "type": "integer",
                        "description": "Page number (default: 1)",
                        "minimum": 1
                    }
                },
                "required": ["author"]
            }
        },
        {
            "name": "guardian_find_related",
            "description": "Find articles related to a given article using shared tags",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "article_id": {
                        "type": "string",
                        "description": "Guardian article ID to find related articles for"
                    },
                    "similarity_threshold": {
                        "type": "integer",
                        "description": "Minimum number of shared tags required (default: 2)",
                        "minimum": 1,
                        "maximum": 10
                    },
                    "exclude_same_section": {
                        "type": "boolean",
                        "description": "Exclude articles from the same section (default: false)"
                    },
                    "max_days_old": {
                        "type": "integer",
                        "description": "Only find articles within this many days of the original (default: unlimited)",
                        "minimum": 1
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Results per page, max 50 (default: 10)",
                        "minimum": 1,
                        "maximum": 50
                    }
                },
                "required": ["article_id"]
            }
        }
    ]
    
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "tools": tools
        }
    }

def handle_tool_call(request_id: Any, params: Dict[str, Any]) -> Dict[str, Any]:
    """Handle tool execution"""
    tool_name = params.get("name")
    arguments = params.get("arguments", {})
    
    try:
        result = ""
        
        if tool_name == "guardian_search":
            # Build search parameters
            search_params = {}
            
            if arguments.get("query"):
                search_params["q"] = arguments["query"]
            if arguments.get("section"):
                search_params["section"] = arguments["section"]
            if arguments.get("tag"):
                search_params["tag"] = arguments["tag"]
            if arguments.get("from_date"):
                from_date = validate_date(arguments["from_date"])
                if from_date:
                    search_params["from-date"] = from_date
                else:
                    raise ValueError(f"Invalid from_date format: {arguments['from_date']}. Use YYYY-MM-DD format.")
            if arguments.get("to_date"):
                to_date = validate_date(arguments["to_date"])
                if to_date:
                    search_params["to-date"] = to_date
                else:
                    raise ValueError(f"Invalid to_date format: {arguments['to_date']}. Use YYYY-MM-DD format.")
            
            search_params["order-by"] = arguments.get("order_by", "relevance")
            search_params["page-size"] = arguments.get("page_size", 20)
            search_params["page"] = arguments.get("page", 1)
            
            show_fields = arguments.get("show_fields", "headline,standfirst,byline,publication,firstPublicationDate")
            search_params["show-fields"] = show_fields
            
            if arguments.get("production_office"):
                search_params["production-office"] = arguments["production_office"]
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                pagination = response.get("response", {})
                result = format_article_response(articles, pagination)
        
        elif tool_name == "guardian_get_article":
            article_id = arguments.get("article_id")
            if not article_id:
                raise ValueError("article_id is required")
            
            show_fields = arguments.get("show_fields", "headline,standfirst,body,byline,publication,firstPublicationDate")
            
            # Ensure article_id starts with a forward slash
            if not article_id.startswith("/"):
                article_id = "/" + article_id
            
            response = make_guardian_request(article_id, {"show-fields": show_fields})
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                content = response.get("response", {}).get("content")
                if content:
                    result = format_article_response([content])
                else:
                    result = "Article not found."
        
        elif tool_name == "guardian_longread":
            # Search for Long Read articles using the tag
            search_params = {
                "tag": "news/series/the-long-read",
                "page-size": arguments.get("page_size", 10),
                "page": arguments.get("page", 1),
                "show-fields": "headline,standfirst,body,byline,thumbnail,publication,firstPublicationDate"
            }
            
            if arguments.get("query"):
                search_params["q"] = arguments["query"]
            if arguments.get("from_date"):
                from_date = validate_date(arguments["from_date"])
                if from_date:
                    search_params["from-date"] = from_date
                else:
                    raise ValueError(f"Invalid from_date format: {arguments['from_date']}. Use YYYY-MM-DD format.")
            if arguments.get("to_date"):
                to_date = validate_date(arguments["to_date"])
                if to_date:
                    search_params["to-date"] = to_date
                else:
                    raise ValueError(f"Invalid to_date format: {arguments['to_date']}. Use YYYY-MM-DD format.")
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                pagination = response.get("response", {})
                result = format_article_response(articles, pagination)
        
        elif tool_name == "guardian_lookback":
            date = arguments.get("date")
            if not date:
                raise ValueError("date is required")
            
            from_date = validate_date(date)
            if not from_date:
                raise ValueError(f"Invalid date format: {date}. Use YYYY-MM-DD format.")
            
            search_params = {
                "from-date": from_date,
                "order-by": "newest",
                "page-size": arguments.get("page_size", 20),
                "show-fields": "headline,standfirst,byline,publication,firstPublicationDate"
            }
            
            if arguments.get("end_date"):
                to_date = validate_date(arguments["end_date"])
                if to_date:
                    search_params["to-date"] = to_date
                else:
                    raise ValueError(f"Invalid end_date format: {arguments['end_date']}. Use YYYY-MM-DD format.")
            else:
                # If no end date, use the same date
                search_params["to-date"] = from_date
            
            if arguments.get("section"):
                search_params["section"] = arguments["section"]
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                pagination = response.get("response", {})
                result = format_article_response(articles, pagination)
        
        elif tool_name == "guardian_browse_section":
            section = arguments.get("section")
            if not section:
                raise ValueError("section is required")
            
            days_back = arguments.get("days_back", 7)
            from_date = calculate_date_from_days_back(days_back)
            
            search_params = {
                "section": section,
                "from-date": from_date,
                "order-by": "newest",
                "page-size": arguments.get("page_size", 20),
                "show-fields": "headline,standfirst,byline,publication,firstPublicationDate"
            }
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                pagination = response.get("response", {})
                result = format_article_response(articles, pagination)
        
        elif tool_name == "guardian_get_sections":
            response = make_guardian_request("/sections", {})
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                sections = response.get("response", {}).get("results", [])
                if sections:
                    result = "Available Guardian sections:\n\n"
                    for section in sections:
                        result += f"**{section.get('webTitle', 'Unknown')}**\n"
                        result += f"ID: {section.get('id', 'N/A')}\n"
                        result += f"URL: {section.get('webUrl', 'N/A')}\n\n"
                else:
                    result = "No sections found."
        
        elif tool_name == "guardian_search_tags":
            query = arguments.get("query")
            if not query:
                raise ValueError("query is required for tag search")
            
            search_params = {
                "q": query,
                "page-size": arguments.get("page_size", 20),
                "page": arguments.get("page", 1)
            }
            
            response = make_guardian_request("/tags", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                tags = response.get("response", {}).get("results", [])
                pagination = response.get("response", {})
                
                if tags:
                    result = f"Found {len(tags)} tag(s) matching '{query}':\n\n"
                    for i, tag in enumerate(tags, 1):
                        result += f"**{i}. {tag.get('webTitle', 'Unknown')}**\n"
                        result += f"ID: {tag.get('id', 'N/A')}\n"
                        result += f"Type: {tag.get('type', 'N/A')}\n"
                        result += f"URL: {tag.get('webUrl', 'N/A')}\n\n"
                    
                    if pagination.get('pages', 1) > 1:
                        current_page = pagination.get('currentPage', 1)
                        total_pages = pagination.get('pages', 1)
                        result += f"\nPagination: Page {current_page} of {total_pages}\n"
                else:
                    result = f"No tags found matching '{query}'."
        
        elif tool_name == "guardian_search_by_length":
            # Build search parameters
            search_params = {
                "show-fields": "headline,standfirst,byline,publication,firstPublicationDate,wordcount",
                "order-by": arguments.get("order_by", "newest"),
                "page-size": min(arguments.get("page_size", 20), 200)  # Get max for filtering
            }
            
            if arguments.get("query"):
                search_params["q"] = arguments["query"]
            if arguments.get("section"):
                search_params["section"] = arguments["section"]
            if arguments.get("from_date"):
                from_date = validate_date(arguments["from_date"])
                if from_date:
                    search_params["from-date"] = from_date
                else:
                    raise ValueError(f"Invalid from_date format: {arguments['from_date']}. Use YYYY-MM-DD format.")
            if arguments.get("to_date"):
                to_date = validate_date(arguments["to_date"])
                if to_date:
                    search_params["to-date"] = to_date
                else:
                    raise ValueError(f"Invalid to_date format: {arguments['to_date']}. Use YYYY-MM-DD format.")
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                
                # Filter by word count
                min_words = arguments.get("min_words", 0)
                max_words = arguments.get("max_words", float('inf'))
                
                filtered_articles = []
                for article in articles:
                    word_count = article.get("fields", {}).get("wordcount")
                    if word_count and word_count.isdigit():
                        word_count = int(word_count)
                        if min_words <= word_count <= max_words:
                            filtered_articles.append(article)
                
                if filtered_articles:
                    result = f"Found {len(filtered_articles)} article(s) with {min_words}-{max_words if max_words != float('inf') else '∞'} words:\n\n"
                    for i, article in enumerate(filtered_articles, 1):
                        result += f"**{i}. {article.get('webTitle', 'Untitled')}**\n"
                        
                        if 'fields' in article:
                            fields = article['fields']
                            if 'byline' in fields:
                                result += f"By: {fields['byline']}\n"
                            if 'firstPublicationDate' in fields:
                                pub_date = fields['firstPublicationDate'][:10]
                                result += f"Published: {pub_date}\n"
                            if 'wordcount' in fields:
                                result += f"Word count: {fields['wordcount']}\n"
                            if 'standfirst' in fields and fields['standfirst']:
                                result += f"Summary: {fields['standfirst']}\n"
                        
                        result += f"Section: {article.get('sectionName', 'Unknown')}\n"
                        result += f"URL: {article.get('webUrl', 'N/A')}\n\n"
                else:
                    result = f"No articles found with word count between {min_words} and {max_words if max_words != float('inf') else '∞'} words."
        
        elif tool_name == "guardian_search_by_author":
            author = arguments.get("author")
            if not author:
                raise ValueError("author is required")
            
            # Build search parameters - we'll search for the author name in the byline
            search_params = {
                "show-fields": "headline,standfirst,byline,publication,firstPublicationDate,wordcount",
                "order-by": arguments.get("order_by", "newest"),
                "page-size": arguments.get("page_size", 20),
                "page": arguments.get("page", 1)
            }
            
            # Combine author search with optional query
            if arguments.get("query"):
                search_params["q"] = f'"{author}" {arguments["query"]}'
            else:
                search_params["q"] = f'"{author}"'
            
            if arguments.get("section"):
                search_params["section"] = arguments["section"]
            if arguments.get("from_date"):
                from_date = validate_date(arguments["from_date"])
                if from_date:
                    search_params["from-date"] = from_date
                else:
                    raise ValueError(f"Invalid from_date format: {arguments['from_date']}. Use YYYY-MM-DD format.")
            if arguments.get("to_date"):
                to_date = validate_date(arguments["to_date"])
                if to_date:
                    search_params["to-date"] = to_date
                else:
                    raise ValueError(f"Invalid to_date format: {arguments['to_date']}. Use YYYY-MM-DD format.")
            
            response = make_guardian_request("/search", search_params)
            
            if "error" in response:
                result = f"Error: {response['error']}"
            else:
                articles = response.get("response", {}).get("results", [])
                
                # Filter to only articles where the author name appears in the byline
                author_articles = []
                for article in articles:
                    byline = article.get("fields", {}).get("byline", "")
                    if byline and author.lower() in byline.lower():
                        author_articles.append(article)
                
                if author_articles:
                    pagination = response.get("response", {})
                    result = f"Found {len(author_articles)} article(s) by {author}:\n\n"
                    
                    for i, article in enumerate(author_articles, 1):
                        result += f"**{i}. {article.get('webTitle', 'Untitled')}**\n"
                        
                        if 'fields' in article:
                            fields = article['fields']
                            if 'byline' in fields:
                                result += f"By: {fields['byline']}\n"
                            if 'firstPublicationDate' in fields:
                                pub_date = fields['firstPublicationDate'][:10]
                                result += f"Published: {pub_date}\n"
                            if 'wordcount' in fields:
                                result += f"Word count: {fields['wordcount']}\n"
                            if 'standfirst' in fields and fields['standfirst']:
                                result += f"Summary: {fields['standfirst']}\n"
                        
                        result += f"Section: {article.get('sectionName', 'Unknown')}\n"
                        result += f"URL: {article.get('webUrl', 'N/A')}\n\n"
                    
                    if pagination.get('pages', 1) > 1:
                        current_page = pagination.get('currentPage', 1)
                        total_pages = pagination.get('pages', 1)
                        result += f"\nPagination: Page {current_page} of {total_pages}\n"
                else:
                    result = f"No articles found by author '{author}'."
        
        elif tool_name == "guardian_find_related":
            article_id = arguments.get("article_id")
            if not article_id:
                raise ValueError("article_id is required")
            
            # Ensure article_id starts with a forward slash
            if not article_id.startswith("/"):
                article_id = "/" + article_id
            
            # First, get the original article with all its tags
            response = make_guardian_request(article_id, {"show-tags": "all", "show-fields": "headline,firstPublicationDate"})
            
            if "error" in response:
                result = f"Error fetching original article: {response['error']}"
            else:
                original_article = response.get("response", {}).get("content")
                if not original_article:
                    result = "Original article not found."
                else:
                    original_tags = original_article.get("tags", [])
                    original_section = original_article.get("sectionId")
                    original_date = original_article.get("webPublicationDate", "")
                    
                    if not original_tags:
                        result = "Original article has no tags for similarity matching."
                    else:
                        # Extract key tags (excluding very generic ones)
                        useful_tags = []
                        for tag in original_tags:
                            tag_id = tag.get("id", "")
                            tag_type = tag.get("type", "")
                            # Focus on more specific tags
                            if tag_type in ["keyword", "contributor", "series"] and len(tag_id.split("/")) >= 2:
                                useful_tags.append(tag_id)
                        
                        if not useful_tags:
                            result = "Original article has no specific tags for similarity matching."
                        else:
                            # Search for articles with shared tags
                            similarity_threshold = arguments.get("similarity_threshold", 2)
                            exclude_same_section = arguments.get("exclude_same_section", False)
                            max_days_old = arguments.get("max_days_old")
                            
                            related_articles = []
                            
                            # Search for each tag and collect results
                            for tag in useful_tags[:5]:  # Limit to first 5 tags to avoid too many API calls
                                search_params = {
                                    "tag": tag,
                                    "show-tags": "all",
                                    "show-fields": "headline,standfirst,byline,publication,firstPublicationDate",
                                    "page-size": 20
                                }
                                
                                if exclude_same_section and original_section:
                                    # We can't exclude sections via API, will filter later
                                    pass
                                
                                if max_days_old and original_date:
                                    # Calculate date range
                                    from datetime import datetime, timedelta
                                    orig_date = datetime.fromisoformat(original_date.replace('Z', '+00:00'))
                                    min_date = (orig_date - timedelta(days=max_days_old)).strftime('%Y-%m-%d')
                                    max_date = (orig_date + timedelta(days=max_days_old)).strftime('%Y-%m-%d')
                                    search_params["from-date"] = min_date
                                    search_params["to-date"] = max_date
                                
                                tag_response = make_guardian_request("/search", search_params)
                                if "error" not in tag_response:
                                    articles = tag_response.get("response", {}).get("results", [])
                                    for article in articles:
                                        if article.get("id") != original_article.get("id"):  # Exclude original
                                            related_articles.append(article)
                            
                            # Count shared tags and rank by similarity
                            similarity_scores = {}
                            for article in related_articles:
                                article_id_key = article.get("id")
                                if article_id_key not in similarity_scores:
                                    article_tags = [tag.get("id") for tag in article.get("tags", [])]
                                    shared_count = len(set(useful_tags) & set(article_tags))
                                    
                                    # Apply filters
                                    if exclude_same_section and article.get("sectionId") == original_section:
                                        continue
                                    
                                    if shared_count >= similarity_threshold:
                                        similarity_scores[article_id_key] = {
                                            "article": article,
                                            "shared_tags": shared_count
                                        }
                            
                            # Sort by similarity and limit results
                            page_size = arguments.get("page_size", 10)
                            sorted_similar = sorted(similarity_scores.values(), 
                                                  key=lambda x: x["shared_tags"], reverse=True)[:page_size]
                            
                            if sorted_similar:
                                result = f"Found {len(sorted_similar)} related article(s) to '{original_article.get('webTitle', 'Unknown')}':\n\n"
                                
                                for i, item in enumerate(sorted_similar, 1):
                                    article = item["article"]
                                    shared_count = item["shared_tags"]
                                    
                                    result += f"**{i}. {article.get('webTitle', 'Untitled')}** (Similarity: {shared_count} shared tags)\n"
                                    
                                    if 'fields' in article:
                                        fields = article['fields']
                                        if 'byline' in fields:
                                            result += f"By: {fields['byline']}\n"
                                        if 'firstPublicationDate' in fields:
                                            pub_date = fields['firstPublicationDate'][:10]
                                            result += f"Published: {pub_date}\n"
                                        if 'standfirst' in fields and fields['standfirst']:
                                            result += f"Summary: {fields['standfirst']}\n"
                                    
                                    result += f"Section: {article.get('sectionName', 'Unknown')}\n"
                                    result += f"URL: {article.get('webUrl', 'N/A')}\n\n"
                            else:
                                result = f"No related articles found with at least {similarity_threshold} shared tags."
        
        else:
            raise ValueError(f"Unknown tool: {tool_name}")
        
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "content": [
                    {
                        "type": "text",
                        "text": result
                    }
                ]
            }
        }
    
    except Exception as e:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": -32603,
                "message": str(e)
            }
        }

def main():
    """Main server loop"""
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break
            
            request = json.loads(line.strip())
            method = request.get("method")
            request_id = request.get("id")
            params = request.get("params", {})
            
            if method == "initialize":
                response = handle_initialize(request_id)
            elif method == "tools/list":
                response = handle_tools_list(request_id)
            elif method == "tools/call":
                response = handle_tool_call(request_id, params)
            else:
                response = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {method}"
                    }
                }
            
            send_response(response)
            
        except json.JSONDecodeError:
            continue
        except EOFError:
            break
        except Exception as e:
            if 'request_id' in locals():
                send_response({
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32603,
                        "message": f"Internal error: {str(e)}"
                    }
                })

if __name__ == "__main__":
    main()