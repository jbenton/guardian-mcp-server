#!/bin/bash

# Guardian MCP Server Setup Script

echo "🗞️  Guardian MCP Server Setup"
echo "=============================="

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is required but not installed."
    echo "   Please install Python 3.7+ and try again."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "✅ Python $PYTHON_VERSION found"

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    echo "❌ Error: pip3 is required but not found."
    echo "   Please install pip3 and try again."
    exit 1
fi

echo "📦 Installing Python dependencies..."
pip3 install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to install dependencies."
    exit 1
fi

echo "✅ Dependencies installed successfully"

# Make server executable
chmod +x server.py
echo "✅ Server permissions set"

# Check if API key is already set
if [ -n "$GUARDIAN_API_KEY" ]; then
    echo "✅ Guardian API key is already set in environment"
else
    echo ""
    echo "🔑 Guardian API Key Setup"
    echo "========================"
    echo "You need a Guardian API key to use this server."
    echo ""
    echo "To get your free API key:"
    echo "1. Visit: https://open-platform.theguardian.com/access/"
    echo "2. Register for an account"
    echo "3. Request an API key (500 free calls per day)"
    echo ""
    
    read -p "Do you have your API key ready? (y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo ""
        read -p "Enter your Guardian API key: " api_key
        
        if [ -n "$api_key" ]; then
            # Create .env file
            echo "GUARDIAN_API_KEY=$api_key" > .env
            echo "✅ API key saved to .env file"
            
            # Also export for current session
            export GUARDIAN_API_KEY="$api_key"
            echo "✅ API key set for current session"
            
            echo ""
            echo "To make this permanent, add this line to your shell profile:"
            echo "export GUARDIAN_API_KEY=\"$api_key\""
        else
            echo "⚠️  No API key entered. You'll need to set GUARDIAN_API_KEY environment variable later."
        fi
    else
        echo ""
        echo "⚠️  Please get your API key from https://open-platform.theguardian.com/access/"
        echo "   Then run: export GUARDIAN_API_KEY=\"your-key-here\""
    fi
fi

echo ""
echo "🧪 Testing server setup..."

# Test server initialization
if [ -n "$GUARDIAN_API_KEY" ]; then
    # Test basic initialization
    test_output=$(echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' | python3 server.py 2>&1)
    
    if echo "$test_output" | grep -q '"protocolVersion"'; then
        echo "✅ Server initialization test passed"
        
        # Test tools list
        tools_output=$(echo '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | python3 server.py 2>&1)
        
        if echo "$tools_output" | grep -q 'guardian_search'; then
            echo "✅ Tools registration test passed"
        else
            echo "⚠️  Tools registration test failed"
        fi
    else
        echo "⚠️  Server initialization test failed"
        echo "Debug output: $test_output"
    fi
else
    echo "⚠️  Skipping server test (no API key set)"
fi

echo ""
echo "🎉 Setup complete!"
echo ""
echo "📚 Quick Start:"
echo "   1. Ensure your API key is set: echo \$GUARDIAN_API_KEY"
echo "   2. Test the server: python3 server.py"
echo "   3. Read the README.md for usage examples"
echo ""
echo "🔧 Available tools:"
echo "   - guardian_search: Search Guardian articles"
echo "   - guardian_get_article: Get full article content"
echo "   - guardian_longread: Search Long Read articles"
echo "   - guardian_lookback: Historical date searches"
echo "   - guardian_browse_section: Browse by section"
echo "   - guardian_get_sections: List all sections"
echo "   - guardian_search_tags: Search available tags"
echo ""
echo "📖 For detailed usage instructions, see README.md"

if [ -z "$GUARDIAN_API_KEY" ]; then
    echo ""
    echo "⚠️  IMPORTANT: Don't forget to set your Guardian API key!"
    echo "   export GUARDIAN_API_KEY=\"your-key-here\""
fi