# Guardian MCP Server - TypeScript/Node.js Conversion PRD

## Project Overview

Convert the existing Python Guardian MCP server to TypeScript/Node.js for better portability, ecosystem alignment, and public distribution. The Python version has successfully validated all Guardian API endpoints and functionality - this conversion focuses on creating a production-ready, npm-distributable package.

## Background Context

**Existing Python Implementation**: `/Users/Job876/guardian-mcp-server/`
- ✅ All Guardian API endpoints validated and working
- ✅ 10 comprehensive tools implemented
- ✅ Proper error handling and rate limiting
- ❌ Distribution requires Python virtual environments
- ❌ MCP protocol validation errors in Claude Desktop
- ❌ Not aligned with ecosystem standards (most MCP servers use npm/npx)

**Target Outcome**: TypeScript/Node.js MCP server that can be installed with `npx guardian-mcp-server`

## Requirements

### Core Functionality
Convert all 10 existing Python tools to TypeScript, maintaining exact same functionality:

1. **`guardian_search`** - Search Guardian articles with comprehensive filtering
2. **`guardian_get_article`** - Retrieve full article content by ID
3. **`guardian_longread`** - Search The Long Read series specifically
4. **`guardian_lookback`** - Historical date-based searches
5. **`guardian_browse_section`** - Browse recent articles by section
6. **`guardian_get_sections`** - List all available Guardian sections
7. **`guardian_search_tags`** - Search through 50,000+ available tags
8. **`guardian_search_by_length`** - Filter articles by word count range
9. **`guardian_search_by_author`** - Search articles by specific journalist
10. **`guardian_find_related`** - Find related articles using shared tags

### Technical Requirements

#### **Framework & Dependencies**
- **MCP SDK**: Use `@modelcontextprotocol/sdk` (TypeScript)
- **HTTP Client**: Node.js built-in `fetch` or `axios`
- **Package Manager**: npm with TypeScript compilation
- **Schema Validation**: Zod for parameter validation

#### **API Integration**
- **Base URL**: `https://content.guardianapis.com`
- **Authentication**: Guardian API key via environment variable `GUARDIAN_API_KEY`
- **Rate Limiting**: 500 calls/day (free tier) - implement graceful error handling
- **Error Handling**: Match Python version's comprehensive error responses

#### **Distribution**
- **npm Package**: Publishable to npm registry as `guardian-mcp-server`
- **CLI Support**: `npx guardian-mcp-server` execution
- **Configuration**: Standard MCP JSON-RPC over stdio

### Guardian API Specification

Based on validated Python implementation, the Guardian API uses these endpoints:

#### **Search Endpoint**: `/search`
**Parameters**:
- `q` (optional): Search terms
- `section` (optional): Section ID filter
- `tag` (optional): Tag filter
- `from-date` (optional): Start date (YYYY-MM-DD)
- `to-date` (optional): End date (YYYY-MM-DD)
- `order-by` (optional): "newest", "oldest", "relevance"
- `page-size` (optional): Results per page (max 200)
- `page` (optional): Page number
- `show-fields` (optional): Comma-separated field list
- `production-office` (optional): "uk", "us", "au"
- `api-key` (required): API authentication

#### **Single Article**: `/{article-id}`
**Parameters**:
- `show-fields` (optional): Fields to include
- `api-key` (required)

#### **Sections Endpoint**: `/sections`
**Parameters**:
- `api-key` (required)

#### **Tags Endpoint**: `/tags`
**Parameters**:
- `q` (optional): Tag search query
- `page-size` (optional): Results per page
- `page` (optional): Page number
- `api-key` (required)

### Long Read Implementation
The Python version discovered that Long Read articles use the tag: `news/series/the-long-read`
- Implement as search with this specific tag filter
- Verify tag exists during development

### Project Structure
```
guardian-mcp-server/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts          # Main server entry point
│   ├── tools/            # Individual tool implementations
│   ├── api/              # Guardian API client
│   ├── types/            # TypeScript interfaces
│   └── utils/            # Helper functions
├── dist/                 # Compiled JavaScript
├── README.md
└── .env.example
```

### Package.json Requirements
```json
{
  "name": "guardian-mcp-server",
  "version": "1.0.0",
  "description": "MCP server for The Guardian newspaper archive access",
  "main": "dist/index.js",
  "type": "module",
  "bin": {
    "guardian-mcp-server": "./dist/index.js"
  },
  "scripts": {
    "build": "tsc",
    "start": "node dist/index.js",
    "dev": "tsc --watch"
  },
  "keywords": ["mcp", "guardian", "newspaper", "journalism", "news"],
  "dependencies": {
    "@modelcontextprotocol/sdk": "latest",
    "zod": "^3.21.4"
  },
  "devDependencies": {
    "@types/node": "^18.15.11",
    "typescript": "^5.0.4"
  }
}
```

## Tool Specifications

### 1. guardian_search
**Input Schema**:
```typescript
{
  query?: string;
  section?: string;
  tag?: string;
  from_date?: string;
  to_date?: string;
  order_by?: "newest" | "oldest" | "relevance";
  page_size?: number; // 1-200
  page?: number;
  show_fields?: string;
  production_office?: "uk" | "us" | "au";
}
```

### 2. guardian_get_article
**Input Schema**:
```typescript
{
  article_id: string; // Required
  show_fields?: string;
}
```

### 3. guardian_longread
**Input Schema**:
```typescript
{
  query?: string;
  from_date?: string;
  to_date?: string;
  page_size?: number; // 1-200, default 10
  page?: number;
}
```

### 4. guardian_lookback
**Input Schema**:
```typescript
{
  date: string; // Required, YYYY-MM-DD
  end_date?: string;
  section?: string;
  page_size?: number; // 1-200, default 20
}
```

### 5. guardian_browse_section
**Input Schema**:
```typescript
{
  section: string; // Required
  days_back?: number; // 1-365, default 7
  page_size?: number; // 1-200, default 20
}
```

### 6. guardian_get_sections
**Input Schema**: No parameters

### 7. guardian_search_tags
**Input Schema**:
```typescript
{
  query: string; // Required
  page_size?: number; // 1-200, default 20
  page?: number;
}
```

### 8. guardian_search_by_length
**Input Schema**:
```typescript
{
  query?: string;
  min_words?: number;
  max_words?: number;
  section?: string;
  from_date?: string;
  to_date?: string;
  order_by?: "newest" | "oldest" | "relevance";
  page_size?: number; // 1-200, default 20
}
```

### 9. guardian_search_by_author
**Input Schema**:
```typescript
{
  author: string; // Required
  query?: string;
  section?: string;
  from_date?: string;
  to_date?: string;
  order_by?: "newest" | "oldest" | "relevance";
  page_size?: number; // 1-200, default 20
  page?: number;
}
```

### 10. guardian_find_related
**Input Schema**:
```typescript
{
  article_id: string; // Required
  similarity_threshold?: number; // 1-10, default 2
  exclude_same_section?: boolean;
  max_days_old?: number;
  page_size?: number; // 1-50, default 10
}
```

## Response Formatting

### Article Response Format
Based on successful Python implementation, format responses as:
```
Found X article(s):

**1. [Article Title]**
By: [Author]
Published: [Date]
Summary: [Standfirst]
Section: [Section Name]
URL: [Web URL]
Guardian ID: [Article ID]
Content preview: [Truncated body text]...

**2. [Next Article]**
...

Pagination: Page X of Y
Use the 'page' parameter to get more results.
```

### Error Handling
Implement comprehensive error responses for:
- **Rate limit exceeded** (HTTP 429)
- **Invalid API key** (HTTP 403) 
- **Network timeouts**
- **Invalid date formats**
- **Article not found**
- **Invalid parameters**

## Environment Configuration

### API Key Setup
- **Environment Variable**: `GUARDIAN_API_KEY`
- **Validation**: Check for API key presence on server startup
- **Error Message**: Clear instructions on obtaining key from https://open-platform.theguardian.com/access/

### Claude Desktop Configuration
Target configuration format:
```json
{
  "mcpServers": {
    "guardian": {
      "command": "npx",
      "args": ["guardian-mcp-server"],
      "env": {
        "GUARDIAN_API_KEY": "your-key-here"
      }
    }
  }
}
```

## Testing Requirements

### Validation Steps
1. **Server Initialization**: Proper MCP protocol handshake
2. **Tool Registration**: All 10 tools properly listed
3. **API Integration**: Test with real Guardian API key
4. **Error Handling**: Test rate limits and invalid inputs
5. **Response Formatting**: Verify LLM-friendly output

### Test Cases
- Search recent articles in technology section
- Retrieve specific article by ID
- Browse Long Read articles
- Historical lookback (e.g., Brexit day 2016-06-24)
- Get all sections list
- Search climate-related tags
- Error scenarios (invalid dates, missing API key)

## Documentation Requirements

### README.md
Include comprehensive documentation with:
- **Installation instructions** (`npx guardian-mcp-server`)
- **API key setup process**
- **Claude Desktop configuration**
- **Usage examples for all 10 tools**
- **Rate limiting information**
- **Troubleshooting guide**

### Example Usage
```typescript
// Search recent AI articles
guardian_search({
  query: "artificial intelligence",
  section: "technology", 
  order_by: "newest"
})

// Get Long Read features
guardian_longread({
  query: "climate change",
  from_date: "2024-01-01"
})

// Historical research
guardian_lookback({
  date: "2016-06-24" // Brexit referendum
})
```

## Success Criteria

### Functional Requirements ✅
- [ ] All 10 tools implemented and working
- [ ] Guardian API integration successful  
- [ ] Error handling comprehensive
- [ ] Response formatting LLM-optimized

### Distribution Requirements ✅
- [ ] npm package created
- [ ] `npx guardian-mcp-server` command works
- [ ] No virtual environment dependencies
- [ ] Standard MCP configuration format

### Quality Requirements ✅
- [ ] TypeScript compilation without errors
- [ ] Proper MCP protocol implementation
- [ ] Rate limiting handled gracefully
- [ ] Comprehensive documentation

## Reference Implementation

**Python Version Location**: `/Users/Job876/guardian-mcp-server/`
- Review `server.py` for exact API implementation details
- Copy error handling patterns and response formatting
- Maintain identical tool functionality
- Reference `README.md` for documentation structure

**Guardian API Documentation**: https://open-platform.theguardian.com/documentation/

## Deliverables

1. **TypeScript MCP Server** - Complete, working implementation
2. **npm Package Configuration** - Ready for publishing
3. **Documentation** - Comprehensive README and setup guides
4. **Testing Validation** - Verified working with Claude Desktop
5. **Example Configuration** - Ready-to-use Claude Desktop config

---

**Priority**: High - This replaces a non-portable Python implementation with ecosystem-standard distribution method for public release.